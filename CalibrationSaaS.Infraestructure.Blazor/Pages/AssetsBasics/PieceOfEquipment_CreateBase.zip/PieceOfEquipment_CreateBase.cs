using Blazed.Controls;
using Blazed.Controls.Toast;
using Blazor.IndexedDB.Framework;
using Blazored.Modal;
using Blazored.Modal.Services;


using CalibrationSaaS.Domain.Aggregates.Entities;
using CalibrationSaaS.Domain.Aggregates.ValueObjects;
using CalibrationSaaS.Infraestructure.Blazor;
using CalibrationSaaS.Infraestructure.Blazor.Pages.AssetsBasics;
using CalibrationSaaS.Infraestructure.Blazor.Pages.Basics.TestPoints;
using CalibrationSaaS.Infraestructure.Blazor.Services;
using Grpc.Core;
using Helpers.Controls.ValueObjects;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using ProtoBuf.Grpc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CalibrationSaaS.Infraestructure.Blazor.Pages.Basics
{
    public class PieceOfEquipmen_CreateBase : Base_Create<PieceOfEquipment, Func<IIndexedDbFactory, Application.Services.IPieceOfEquipmentService<CallContext>>, Domain.Aggregates.Shared.Basic.AppState>
    {

        [Inject] public Application.Services.IWorkOrderDetailServices<CallContext> WODServices { get; set; }

        public GroupTestPoint GroupComponent;

        public GroupTestPoint GroupComponent2;

        public CalibrationSaaS.Infraestructure.Blazor.LTI.Rockwell.Scales_Create Scales;


        public ResponsiveTable<PieceOfEquipment> Grid { get; set; } = new ResponsiveTable<PieceOfEquipment>();

        public ResolutionComponent ResolutionComponent;

        public List<PieceOfEquipment> _listPoEDueDate = new List<PieceOfEquipment>();

        [Parameter]
        public Domain.Aggregates.Entities.Customer Customer { get; set; }

        //public string DefaultFilter { get; set; } = "bitterman";
        
        public List<TestCode> TestCodeList { get; set; } = new List<TestCode>();

        [CascadingParameter] 
        public IModalService Modal { get; set; }
        [Inject] Application.Services.IAddressServices _addressService { get; set; }
        [Inject] public Application.Services.IAssetsServices<CallContext> _assetsServices { get; set; }
        [Inject] public Application.Services.IBasicsServices<CallContext> _basicsServices { get; set; }

        [Inject] public Application.Services.ICustomerService<CallContext> _customerServices { get; set; }

        public Blazed.Controls.Typeahead<TestCode, TestCode> Typehead { get; set; }

        public TestCode CurrentTestCode { get; set; }

        public List<User> _userList = new List<User>();
        public List<CalibrationSaaS.Domain.Aggregates.Entities.Customer> _customerList = new List<CalibrationSaaS.Domain.Aggregates.Entities.Customer>();

        public Domain.Aggregates.ValueObjects.AddressResultSet _addressFiltered;

        public WeightSet eqWeightSet = new WeightSet();
        public ICollection<WeightSet> _listWeightSets;

        public Certificate eqCertificate = new Certificate();
        public ICollection<CertificatePoE> _listCetificate = new List<CertificatePoE>();
       
        public bool isDisable { get; set; }
        public int _CustomerId { get; set; }
        public string _CustomerValue { get; set; }

        public int? _EquipmentTemplateID { get; set; }
        public string _Model { get; set; }
        public string _Manufacturer { get; set; }
        public string _Name { get; set; }

        [Parameter]
        public string CustomerId { get; set; }
        [Parameter]
        public string CustomerName { get; set; }
        [Parameter]
        public int AddressId { get; set; }

        [Parameter]
        public string AddressStreet { get; set; }
        public string _message { get; set; }

        public dynamic WeightCreate;

        public Certificate_CreatePoE CertificateCreate = new Certificate_CreatePoE();

        public bool IsAccredited { get; set; }
        public List<PieceOfEquipment> _pieceOfEquipmentsFiltered = new List<PieceOfEquipment>();

        public StatusResultSet _statusList;


        public PieceOfEquipment _listPoEIndicator = new PieceOfEquipment();

        public ICollection<WorkOrderDetail> _listWorkOrderDetail = new List<WorkOrderDetail>();
        public WorkOrderDetailHist_Search WorkOrderDetailSearch = new WorkOrderDetailHist_Search();

        public List<UnitOfMeasure> UnitofMeasureList { get; set; }

        //[CascadingParameter] BlazoredModalInstance _BlazoredModal { get; set; }
        
        public JavaMessage<PieceOfEquipment> JavaMessage2 { get; set; }


        public ModalParameters ModalParameters = new ModalParameters();


        public int CurrentEquipmentType { get; set; }

        public bool editCustomer { get; set; } = false;
        public bool HashCapacity { get; set; }

        public string url { get; set; }
        public string ToleranceLabel { get; set; } = "Tol +/- (HV)";


        public string UncertaintyLabel { get; set; } = "Unc. Block (HV)";

        public async Task ChangeControl2(ChangeEventArgs arg)
        { 
        
            if(arg.Value != null && arg.Value.ToString() == "1")
            {

                ToleranceLabel= "Tol +/- (HV)";
                UncertaintyLabel= "Unc. Block (HV)";

            }

            if (arg.Value != null && arg.Value.ToString() == "2")
            {

                ToleranceLabel = "Tol +/- (HK)";
                UncertaintyLabel = "Unc. Block (HK)";

            }




        }


        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            IsAccredited = false;
            if (_listCetificate != null && CertificateCreate != null && eq.IsWeigthSet && firstRender)
            {

                CertificateCreate.Show(_listCetificate.ToList());

            }
            if (eq.EquipmentTemplate != null && eq.EquipmentTemplate.EquipmentTypeObject.CalibrationTypeID != 1)
            {
                IsAccredited = false;
            }
            await base.OnAfterRenderAsync(firstRender); 

        }


        public async Task LoadResolution()

        {
            if (eq.DueDate.ToString("MM/dd/yyyy") == "01/01/0001")
                eq.DueDate = DateTime.Now;

            if (eq.IsToleranceImport == false)
            {
                var equipmentTemplate = eq?.EquipmentTemplate;


                if (equipmentTemplate == null)
                {
                    return;
                }

                if (eq != null && eq.ToleranceTypeID == 0 && equipmentTemplate?.ToleranceTypeID > 0)
                {
                    eq.ToleranceTypeID = equipmentTemplate.ToleranceTypeID.Value;

                }


                if (eq != null && eq.AccuracyPercentage == 0 && equipmentTemplate?.AccuracyPercentage > 0)
                {
                    eq.AccuracyPercentage = equipmentTemplate.AccuracyPercentage;

                }

                if (eq != null && eq.Resolution == 0 && equipmentTemplate?.Resolution > 0)
                {
                    eq.Resolution = equipmentTemplate.Resolution;

                }

                
                if (equipmentTemplate?.Ranges != null && equipmentTemplate?.Ranges?.Count > 0)
                {
                    eq.Ranges = equipmentTemplate.Ranges;

                }

                if (eq != null && eq.ClassHB44 == 0 && equipmentTemplate?.ClassHB44 > 0)
                {
                    eq.ClassHB44 = equipmentTemplate.ClassHB44;
                }

                if (eq != null && eq.ToleranceFixedValue == 0 && equipmentTemplate?.ToleranceFixedValue > 0)
                {
                    eq.ToleranceFixedValue = equipmentTemplate.ToleranceFixedValue;

                }

                if (eq == null || eq.CalibrationDate.Year == 1)
                {
                    eq.CalibrationDate = DateTime.Now;
                }

            }

            //if (ResolutionComponent != null)
            //{
            //    EquipmentTemplate et = new EquipmentTemplate();
            //    et.ToleranceTypeID = eq.ToleranceTypeID;
            //    et.AccuracyPercentage = eq.AccuracyPercentage;
            //    et.Resolution = eq.Resolution;
            //    et.DecimalNumber = eq.DecimalNumber;

            //    et.ClassHB44 = eq.ClassHB44;
            //    var tol = ResolutionComponent.IsToleranceImport;
            //    eq.IsToleranceImport = tol;



            //    et.Ranges = eq.Ranges;

            //    await ResolutionComponent.Show(et);
            //}

            if (ResolutionComponent != null)
            {
                EquipmentTemplate et = new EquipmentTemplate();
                et.ToleranceTypeID = eq.ToleranceTypeID;
                et.AccuracyPercentage = eq.AccuracyPercentage;
                et.Resolution = eq.Resolution;
                et.DecimalNumber = eq.DecimalNumber;
                et.ToleranceFixedValue = eq.ToleranceFixedValue;
                ////////Ranges
                ///

                et.ClassHB44 = eq.ClassHB44;
                var tol = ResolutionComponent.IsToleranceImport;
                eq.IsToleranceImport = tol;


                //if (eq.IsToleranceImport == true && ResolutionComponent != null)
                //{

                //    List<RangeTolerance> rl = new List<RangeTolerance>();
                //    var rangecom = ResolutionComponent?.RangeComponent;
                //    if (rangecom?.RT?.Items?.Count > 0)
                //    {
                //        var re2 = rangecom.RT.Items;
                //        rl.AddRange(re2);

                //    }

                //    var resolcom = ResolutionComponent?.RangeAccuracy;
                //    if (resolcom?.RT?.Items?.Count > 0)
                //    {
                //        var re3 = resolcom.RT.Items;
                //        rl.AddRange(re3);
                //    }
                //    //if (rl.Count > 0)
                //    //{
                //    eq.Ranges = rl;
                //    //}
                //}


                et.Ranges = eq.Ranges;
                //if (!eq.IsToleranceImport)
                //{
                //    et.ToleranceTypeID = 0;
                //    et.AccuracyPercentage = 0;
                //    et.Resolution =0;
                //    et.DecimalNumber = 0;
                //    et.Ranges = null;
                //}

                await ResolutionComponent.Show(et);
            }


        }



        public EquipmentTemplate ET;

        public async Task LoadET(EquipmentTemplate ET)
        {

            if (ET == null)
            {
                return;
            }

            eq.EquipmentTemplate = ET;

            _EquipmentTemplateID = ET.EquipmentTemplateID;
            _Model = ET.Model;

            _Manufacturer = ET.Manufacturer1.Name; 

            _Name = _Manufacturer + " - " + _Model; 

           
            CurrentEditContext.NotifyValidationStateChanged();
            _message = "";

            if (eq.Capacity == 0 && ET.Capacity >= 0)
            {
                eq.Capacity = ET.Capacity;
                eq.UnitOfMeasureID = ET.UnitofmeasurementID;
            }

            if (eq.EquipmentTemplate.EquipmentTypeObject.HasWorkOrderDetail)
                {
                    eq.IsWeigthSet = false;
                    eq.IsStandard = false;
                }
           

            if (eq.EquipmentTemplate.EquipmentTypeObject.HasWorkOrderDetail && eq.EquipmentTemplate.EquipmentTypeObject.IsBalance)
            {
                IsScale = true;
            }
            else
            {
                IsScale = false;
            }

            if (eq.EquipmentTemplate.EquipmentTypeObject.HasCapacity)
            {
                HashCapacity = true;
            }
            else
            {
                HashCapacity = false;
            }


            if (ET.EquipmentTypeObject.HasStandard || ET.EquipmentTypeObject.HasStandardConfiguration)
            {
                eq.IsWeigthSet = true;
                eq.IsStandard = true;
                IsScale = false;

                if (!string.IsNullOrEmpty(ET.EquipmentTypeObject.DefaultCustomer))
                {
                    Pagination<Domain.Aggregates.Entities.Customer> pag = new Pagination<Domain.Aggregates.Entities.Customer>();
                    pag.Filter = ET.EquipmentTypeObject.DefaultCustomer;
                    CustomerGRPC _customerGrpc = new CustomerGRPC(_customerServices);
                    var Eq1 = (await _customerGrpc.GetCustomers(pag, new CallOptions()));

                    if (Eq1?.List?.Count == 1)
                    {
                        eq.CustomerId = Eq1.List[0].CustomerID;
                        _CustomerId = eq.CustomerId;


                        _CustomerValue = Eq1.List[0].Name;

                        eq.Customer = Eq1.List[0];

                    }
                }
               

            }
            else
            {
                eq.IsWeigthSet = false;
                eq.IsStandard = false;

            }




            StateHasChanged();
        }

        public async Task AfterValues()

        { 
          GroupComponent.MapObject();


         var eTC= GroupComponent.Eq;
         eq.TestGroups = eTC.TestGroups;
        
        }

        public  async Task UpdateValues()

        {
           
            GroupComponent.Eq.Resolution = ResolutionComponent.eq.Resolution;
            GroupComponent.Eq.AccuracyPercentage = ResolutionComponent.eq.AccuracyPercentage;
            GroupComponent.Eq.ToleranceTypeID = ResolutionComponent.eq.ToleranceTypeID;
            GroupComponent.Eq.ClassHB44 = ResolutionComponent.eq.ClassHB44;
            GroupComponent.Eq.Ranges = ResolutionComponent.eq.Ranges;
            GroupComponent.Eq.TestGroups = eq.TestGroups;
            GroupComponent.Eq.ToleranceFixedValue = eq.ToleranceFixedValue;
        }
        
        

        [Inject]
        public CalibrationSaaS.Application.Services.IFileUpload fileUpload { get; set; }

        public CalibrationSaaS.Infraestructure.Blazor.LTI.UncertaintyComponent UncertaintyComponent { get; set; }


        public CalibrationSaaS.Infraestructure.Blazor.Shared.CalibrationTypeComponent<PieceOfEquipment,GenericCalibration2,GenericCalibrationResult2> CalibrationTypeComponent { get; set; }

        protected async Task FormSubmitted(EditContext editContext)
        {
            try
            {
                EquipmentTemplate ETC = null;

                if(GroupComponent != null)
                {
                     GroupComponent.MapObject();


                ETC= GroupComponent.Eq;
                     eq.TestGroups = ETC.TestGroups;
                }



                

               
                await ShowProgress();

                 if (string.IsNullOrEmpty(eq.PieceOfEquipmentID))
                {
                    eq.PieceOfEquipmentID = Guid.NewGuid().ToString();
                }
                
                Saving = true;

                var tg1 = new List<TestPointGroup>();
               
                

                Tenant tenant = new Tenant();

                

                if(eq?.EquipmentTemplate?.EquipmentTypeObject != null && eq.EquipmentTemplate.EquipmentTypeObject.HasWorkOrderDetail)
                {

                        if (eq.EquipmentTemplate.EquipmentTypeObject.HasWorkOrderDetail)
                        {
                        eq.IsWeigthSet = false;
                        eq.IsStandard = false;
                        }
                        if (eq.EquipmentTemplate.EquipmentTypeObject.HasTolerance && eq.EquipmentTemplate != null && ResolutionComponent != null && ResolutionComponent.eq != null)
                        {

                            if (!ResolutionComponent.eq.ToleranceTypeID.HasValue)
                            {
                                await ShowError("Review Tolerance Type");
                                return;
                            }

                            eq.ToleranceTypeID = ResolutionComponent.eq.ToleranceTypeID.Value;
                            eq.Resolution = ResolutionComponent.eq.Resolution;
                            eq.AccuracyPercentage = ResolutionComponent.eq.AccuracyPercentage;
                            eq.ClassHB44 = ResolutionComponent.eq.ClassHB44;
                            eq.Ranges = ResolutionComponent.eq.Ranges;
                            eq.ToleranceFixedValue = ResolutionComponent.eq.ToleranceFixedValue;
                        }

                        if (eq.UnitOfMeasureID.HasValue==false)
                        {
                            await ShowError("Unit of Measure error");
                            return;
                        }
                         if (eq.EquipmentTemplate.EquipmentTypeObject.HasWorkOrderDetail && eq.Capacity==0)
                        {
                            await ShowError("Capacity error");
                            return;
                        }


                         Console.WriteLine("Equipmenttypeok");

                        if (IsScale)
                      {


                         var tespointpresent = eq.EquipmentTemplate.EquipmentTypeObject.HasTestpoint;
                        if (eq.EquipmentTemplate.EquipmentTypeObject.HasTestpoint)
                        {
                        
                        if (eq?.TestGroups?.Count == 0 || eq?.TestGroups?.ElementAtOrDefault(0)?.TestPoints ==null || eq?.TestGroups?.ElementAtOrDefault(0)?.TestPoints?.Count == 0)
                        {
                            tespointpresent = false;
                            await ShowToast("No tespoints configured...", ToastLevel.Warning);
                        
                        }
                        }
                   

                        if (eq.EquipmentTemplate.EquipmentTypeObject.HasTolerance && (eq.ToleranceTypeID == 0 || !eq.UnitOfMeasureID.HasValue || eq.UnitOfMeasureID == 0 || eq.Capacity == 0))
                        {
                            await ShowToast("Review Capacity or Tolerance Values", ToastLevel.Warning);
                          
                        }
                        else if(tespointpresent)
                        {
                            Console.WriteLine("poe 1");
                           
                                Console.WriteLine("poe 2");
                            if (eq.IsTestPointImport == false)
                            {
                                Console.WriteLine("poe 3");
                                eq.TestGroups = null;

                            }
                            else
                            {
                                Console.WriteLine("poe 5");

                                Console.WriteLine("poe 7");
                                if (ETC.TestGroups.Count > 0)
                                {
                                    Console.WriteLine("poe 9");


                                }
                                Console.WriteLine("poe 10");
                                if (eq?.TestGroups?.Count > 0)
                                {
                                    Console.WriteLine("poe 10.5");
                                    foreach (var item in eq.TestGroups)
                                    {
                                        item.Type = "POE";
                                        item.TypeID = "POE";
                                        item.PieceOfEquipmentID = eq.PieceOfEquipmentID;
                                        item.EquipmentTemplateID = null;


                                    }
                                    tg1 = eq.TestGroups.ToList();
                                    Console.WriteLine("poe 11");


                                }
                                else
                                {
                                    await ShowToast("No tespoint group configured", ToastLevel.Warning);
                                }

                            }

                       
                        }
                    }
                    else
                    {
                        Console.WriteLine("poe 32");
                        eq.TestGroups = null;
                    }




                }
                else if(eq?.EquipmentTemplate?.EquipmentTypeObject == null)
                {
                    await ShowError("Equipment Template Not Configured, Please select one");
                    return;
                    Console.WriteLine("Equipmenttypeerrororooror");
                }
                else
                {
                     Console.WriteLine("poe 32");
                    eq.TestGroups = null;
                }
               
                

                

                if (eq.IsWeigthSet && (WeightCreate != null && (WeightCreate.RT.Items == null || WeightCreate.RT.Items.Count == 0)))
                {

                    await ShowToast("No Standards Configured", ToastLevel.Warning);

                    eq.WeightSets = null;

                    eq.WeightSets = WeightCreate.RT.ItemList;

                }
                else if (eq.IsWeigthSet && WeightCreate != null &&  WeightCreate.RT.Items.Count > 0)
                {
                    eq.WeightSets = WeightCreate.RT.Items;


                }


                if (eq.IsWeigthSet && (eq.Users == null || eq.Users.Count == 0))
                {

                    await ShowToast("No Technician Configured", ToastLevel.Warning);

                
                }

        
                if (!eq.IsWeigthSet && ResolutionComponent != null)
                {

                    eq.IsToleranceImport = ResolutionComponent.IsToleranceImport;

                    if (!eq.IsToleranceImport)
                    {
                        eq.ToleranceTypeID = 0;
                        eq.Resolution = 0;
                        eq.AccuracyPercentage = 0;
                        eq.Ranges = null;
                        eq.ToleranceFixedValue = 0;
                    }
                    else
                    {
                        eq.ToleranceTypeID = ResolutionComponent.eq.ToleranceTypeID.Value;
                        eq.Resolution = ResolutionComponent.eq.Resolution;
                        eq.AccuracyPercentage = ResolutionComponent.eq.AccuracyPercentage;
                        eq.ClassHB44 = ResolutionComponent.eq.ClassHB44;
                        eq.Ranges = ResolutionComponent.eq.Ranges;
                        eq.ToleranceFixedValue = ResolutionComponent.eq.ToleranceFixedValue;
                        List<RangeTolerance> rl = new List<RangeTolerance>();
                        var rangecom = ResolutionComponent?.RangeComponent;
                        if (rangecom?.RT?.Items?.Count > 0)
                        {
                            var re2 = rangecom.RT.Items;
                            rl.AddRange(re2);

                        }

                        var resolcom = ResolutionComponent?.RangeAccuracy;
                        if (resolcom?.RT?.Items?.Count > 0)
                        {
                            var re3 = resolcom.RT.Items;
                            rl.AddRange(re3);
                        }

                        eq.Ranges = rl;



                    }
                 
                    if (eq.Ranges != null && string.IsNullOrEmpty(eq.PieceOfEquipmentID))
                    {

                        foreach (var r in eq.Ranges)
                        {
                            r.RangeToleranceID = 0;
                            r.PieceOfEquipmentID = eq.PieceOfEquipmentID;
                            r.EquipmentTemplateID = null;


                        }

                    }
                }




                if (eq.POE_POE == null)
                {
                    eq.POE_POE = new List<POE_POE>();
                }
                eq.POE_POE.Clear();
                foreach (var item in _listPoEDueDate)
                {
                    POE_POE poepoe = new POE_POE();

                    poepoe.PieceOfEquipmentID = eq.PieceOfEquipmentID;
                    poepoe.PieceOfEquipmentID2 = item.PieceOfEquipmentID;

                    eq.POE_POE.Add(poepoe);
                }






                eq.CustomerId = _CustomerId;

                eq.EquipmentTemplateId = _EquipmentTemplateID.Value;

                eq.Customer = null;

                eq.EquipmentTemplate = null;


                var HasCert = false;


                if (CertificateCreate?.RT?.Items?.Count() > 0)
                {

                    eq.CertificatePoEs = CertificateCreate.RT.Items;
                    foreach (var certi in eq.CertificatePoEs)
                    {

                        certi.Name = certi.CertificateNumber + "_" + eq.PieceOfEquipmentID + ".pdf";
                        certi.PieceOfEquipmentID = eq.PieceOfEquipmentID;



                    }
                    HasCert = true;
                    CertificatePoE Lastcpo = eq.CertificatePoEs.ElementAtOrDefault(eq.CertificatePoEs.Count() - 1);

                    if (Lastcpo != null && Lastcpo.AffectDueDate && Lastcpo.DueDate > eq.DueDate)
                    {
                        eq.DueDate = Lastcpo.DueDate;
                    }

                }

                if (IsScale && string.IsNullOrEmpty(eq.InstallLocation))
                {
                    throw new Exception("Please fill Install Location");

                }

                 bool formIsValid = await ContextValidation(true);
                LastSubmitResult =
                formIsValid
                ? ""
                : "";


                if(Scales != null)
                {
                    eq.POE_Scale = Scales.RT.ItemList;
                }


                if(CalibrationTypeComponent != null && CalibrationTypeComponent._refs != null && CalibrationTypeComponent._refs.Count > 0) 
                {
                   

                    await CalibrationTypeComponent.CloseGenericWindow();


                    
                }




                if (formIsValid)
                {
                    PieceOfEquipmentGRPC poegrpc = new PieceOfEquipmentGRPC(Client, DbFactory, await CallOptions(Component.Name));
                    if (CurrentTestCode != null)
                        eq.TestCodeID = CurrentTestCode.TestCodeID;

                    Result = await poegrpc.PieceOfEquipmentCreate(eq);

                       eq = Result;

                       if(UncertaintyComponent != null 
                        && UncertaintyComponent.Grid.TableChanges.HasChanges())
                    {
                       


                        foreach(var item in UncertaintyComponent.Grid.TableChanges.DeleteList)
                        {
                            item.PieceOfEquipmentID = Result.PieceOfEquipmentID;
                        }    
                        
                        foreach(var item in UncertaintyComponent.Grid.TableChanges.AddList)
                        {
                            item.PieceOfEquipmentID = Result.PieceOfEquipmentID;
                        }    
                       
                        
                        var unc= await  poegrpc.CreateUncertainty(UncertaintyComponent.Grid.TableChanges);

                        UncertaintyComponent.Grid.TableChanges.Clear();
                    }



                    if (CertificateCreate?.RT?.Items?.Count() > 0 && HasCert && CertificateCreate.fileinfo.Count > 0)
                    {


                            foreach (var certi2 in CertificateCreate?.fileinfo)
                            {
                                 var ccer = CertificateCreate.RT.Items.FirstOrDefault(x => x.Description == certi2.Name);
                                if (ccer != null)
                                {
                                    certi2.Name = ccer.CertificateNumber + "_" + eq.PieceOfEquipmentID + ".pdf";
                                    await fileUpload.UploadAsync(CertificateCreate.fileinfo.ToArray());
                                }
                            }

                       


                    }
                    _listCetificate = await _assetsServices.GetCertificateXPoE(eq);

                    
                    await ShowToast("Information Saved Successfully", ToastLevel.Success);
                    editCustomer = false;       
                    if (IsModal)
                    {
                    await CloseModal(Result);
                    }

                    LastSubmitResult = "Insert was executed";
                }
                else
                {
                    throw new Exception("Not Valid Form");
                }

            }
            catch (RpcException ex)
            {

                await ExceptionManager(ex);

            }
            catch (Exception ex)
            {
                await ExceptionManager(ex);

            }
            finally
            {
                Saving = false;
                
                
                await CloseProgress();

            }

        }


        public async Task<List<GenericCalibrationResult2>> DynamicResult(List<GenericCalibrationResult2> result)
        {

            eq.BasicCalibrationResult= result;  

            return result;
        
        }


        protected override async Task OnInitializedAsync()
        {
            if (eq.DueDate.ToString("MM/dd/yyyy") == "01/01/0001")
                eq.DueDate = DateTime.Now;
            await base.OnInitializedAsync();
            TypeName = "PieceOfEquipment";

            if (IsModal == false)
            {

                AddressId = 0;
                AddressStreet = "Choose";

            }
  
            CalibrationSaaS.Infraestructure.Blazor.Services.BasicsServiceGRPC basics = new CalibrationSaaS.Infraestructure.Blazor.Services.BasicsServiceGRPC(_basicsServices);

  
            var _user = await basics.GetUsers(new CallContext());
            _userList = _user.Users;

    
            var umt = AppState.UnitofMeasureList;
            if (umt != null && umt.Count > 0)
            {
                UnitofMeasureList = umt;
            }

             try
            {
                await ShowProgress();

                 Loading = true;

            if (1==1)
            {
                 _listWeightSets = await _assetsServices.GetWeightSetXPoE(eq);
                Logger.LogDebug("_listWeightSets  onParameters " + _listWeightSets.Count());

                Tenant tenant = new Tenant();

                eq.DueDate = DateTime.Now;
                eq = new CalibrationSaaS.Domain.Aggregates.Entities.PieceOfEquipment();
                eq.DueDate = DateTime.Now;
                if (IsModal == true)
                {
                    _CustomerId = Convert.ToInt32(CustomerId);
                    _CustomerValue = CustomerName;
                    isDisable = true;
                    Console.Write("Customer Id = " + _CustomerId);

                    AddressId = 1;
                    await CustomerChange(_CustomerId.ToString());
                    _addressFiltered.Addresses.FirstOrDefault().AddressId = AddressId;
                    _addressFiltered.Addresses.FirstOrDefault().StreetAddress1 = AddressStreet;
                    eq.AddressId = AddressId;
                        SelectedUser = false;

                        eq.Customer = Customer;

                }
                if (EntityID == "0" || string.IsNullOrEmpty(EntityID))
                {
                    EntityID = "0";

                        eq = new PieceOfEquipment();
                        eq.IsNew = true;
                        eq.EquipmentTemplate = new EquipmentTemplate();
                        eq.EquipmentTemplate.EquipmentTypeObject = new EquipmentType();
                        eq.CalibrationDate = DateTime.Now;
                        eq.DueDate = DateTime.Now;
                        editCustomer = true;
                }
               
                else
                {
                    eq.PieceOfEquipmentID = (EntityID);

                    PieceOfEquipmentGRPC poegrpc = new PieceOfEquipmentGRPC(Client, DbFactory, await CallOptions(Component.Name));
                        //new CallContext()
                        
                    eq = await poegrpc.GetPieceOfEquipmentXId(eq);

                    _listCetificate = await _assetsServices.GetCertificateXPoE(eq);

                    _CustomerId = eq.CustomerId;
                    _CustomerValue = eq.Customer.Name;
                    Console.Write("q.EquipmentTemplateId ---" + eq.EquipmentTemplateId);
                    Console.Write("q.EquipmentTemplate NAME ---  " + eq.EquipmentTemplate.Name);
                    _EquipmentTemplateID = eq.EquipmentTemplateId;

                    _Model = eq.EquipmentTemplate.Model;
                    _Manufacturer = eq.EquipmentTemplate.Manufacturer;

                    _Name = _Manufacturer + " - " + _Model;
                  

                    AddressId = eq.AddressId;
                    AddressStreet = null; 

                    await CustomerChange(_CustomerId.ToString());
                 
                    if (_addressFiltered?.Addresses != null)
                    {
                        var a = _addressFiltered.Addresses.Where(x => x.AddressId == AddressId).FirstOrDefault();
                        if (a != null)
                        {
                            AddressStreet = a.StreetAddress1 + "| " + a.CityID + " " + a.StateID;

                            SelectedUser = false;

                            eq.AddressId = AddressId;


                        }
                    }






                    var res = await poegrpc.GetPieceOfEquipmentHistory(eq);


                    if (res?.WorkOrderDetails != null && res?.WorkOrderDetails?.Count > 0)
                    {

                        _listWorkOrderDetail = res.WorkOrderDetails;
                        WorkOrderDetailSearch.LIST1 = _listWorkOrderDetail.ToList();
                        WorkOrderDetailSearch.Show(_listWorkOrderDetail.ToList());


                    }

                    _listPoEIndicator = eq.Indicator;

                    if (eq.UnitOfMeasureID == null || eq?.UnitOfMeasureID == 0)
                    {
                        eq.UnitOfMeasureID = eq.EquipmentTemplate.UnitofmeasurementID;
                    }

                    CurrentEquipmentType = eq.EquipmentTemplate.EquipmentTypeID;
                        


                    await LoadET(eq.EquipmentTemplate);


                    if (_listPoEIndicator != null && _listPoEIndicator?.PieceOfEquipmentID != null)
                    {
                        SelectedUser = false;
                    }


                    if (eq?.Peripherals != null)
                    {
                        foreach (var item in eq.Peripherals)
                        {
                            _listPoEDueDate.Add(item);
                        }
                    }

                    StateHasChanged();

                }


                _statusList = await _basicsServices.GetStatus(new CallContext());

                if (eq != null)
                {

                    CurrentEditContext = new EditContext(eq);
                }
                StateHasChanged();
                await JSRuntime.InvokeVoidAsync("removeValidClass");
                Logger.LogDebug("calling removeClass");


            }

            _listWeightSets = eq.WeightSets;

            if (_listWeightSets != null && WeightCreate != null)
            {
                IsAccredited = false;

                Logger.LogDebug("IsForAccreditedCal --" + eq.IsForAccreditedCal);

                if (eq.IsForAccreditedCal == true && eq.EquipmentTemplate.EquipmentTypeObject.CalibrationTypeID == 1)
                {
                    IsAccredited = true;
                }
                else
                {
                    IsAccredited = false;
                }
              if (_listWeightSets != null && eq.IsWeigthSet)
                {
                    WeightCreate.Show(_listWeightSets.ToList(), IsAccredited);
                }


            }

            

            if (eq.WeightSets == null)
            {
                eq.WeightSets = new List<WeightSet>();
            }
            if (1 == 1)
            {
                await LoadResolution();
            }


            if (JavaMessage != null && !JavaMessage.IsShowed)
            {
                var red2 = await ConfirmAsync(JavaMessage.Message);
                JavaMessage.Result=red2;    
                
                if(JavaMessage.Result)
                 {
                     eq.Capacity = JavaMessage.Other.Capacity;
                 }
                JavaMessage.IsShowed = true;
            }

            if (JavaMessage2 != null && !JavaMessage2.IsShowed)
            {
                var red = await ConfirmAsync(JavaMessage2.Message);
                JavaMessage2.Result=red;    
                if (JavaMessage2.Result)
                {
                    eq.UnitOfMeasureID = JavaMessage.Other.UnitofmeasurementID;
                }
                JavaMessage2.IsShowed = true;
            }
            Loading = false;

 
                ModalParameters.Add("PieceOfEquipmentID",eq.PieceOfEquipmentID);

                //Component Test Code
                WorkOrderDetailGrpc wod = new WorkOrderDetailGrpc(WODServices);

                var testcodes = await wod.GetTestCodes();

                TestCodeList = testcodes.List;
                CurrentTestCode = await SearchTestCodeSelected(eq.TestCodeID);
                await ScrollPosition();

            }
              catch (RpcException ex)
            {
                await ExceptionManager(ex);
            }

             catch (Exception ex)
            {
                await ExceptionManager(ex);
            }
            finally
            {
                await CloseProgress();
            }



        }

        public new void Dispose()
        {

        }
        public bool IsScale { get; set; }
        public bool SelectedUser { get; set; } = true;
        public async Task ShowModalCustomer()
        {
            Dictionary<string, object> EmptyValidationDictionary = new Dictionary<string, object>();

            var parameters = new ModalParameters();
            parameters.Add("SelectOnly", true);
            parameters.Add("IsModal", true);

            ModalOptions op = new ModalOptions();
            op.ContentScrollable = true;
            op.Class = "blazored-modal " + ModalSize.MediumWindow;

            var messageForm = Modal.Show<CalibrationSaaS.Infraestructure.Blazor.Pages.Customer.Customer_Search>("Select Customer", parameters, op);
            var result = await messageForm.Result;

            if (!result.Cancelled)
            {
  

                eq.Customer = (CalibrationSaaS.Domain.Aggregates.Entities.Customer)result.Data;

                EmptyValidationDictionary = result.Data.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public)
                      .ToDictionary(prop => prop.Name, prop => prop.GetValue(result.Data, null));

                _CustomerId = eq.Customer.CustomerID;
                _CustomerValue = eq.Customer.Name;
                Customer = eq.Customer;
                CalibrationSaaS.Domain.Aggregates.Entities.Customer customer = new CalibrationSaaS.Domain.Aggregates.Entities.Customer()
                {
                    CustomerID = _CustomerId,
                    Name = _CustomerValue
                };
                eq.CustomerId=eq.Customer.CustomerID;
                _customerList.Add(customer);

                await CustomerChange(_CustomerId.ToString());
                if (IsScale)
                {
                    SelectedUser = false;
                }
            }
        }
        public async Task CustomerChange2(CalibrationSaaS.Domain.Aggregates.Entities.Customer _custId)
        {
            if (Client != null)
            {
              
                _addressFiltered = await _assetsServices.GetAddressByCustomerId(_custId);


            }
        }


        public async Task CustomerChange(string customerId)
        {
            if (Client != null)
            {
                CalibrationSaaS.Domain.Aggregates.Entities.Customer _custId = new CalibrationSaaS.Domain.Aggregates.Entities.Customer();
                _custId.CustomerID = Convert.ToInt32(customerId);
                _addressFiltered = await _assetsServices.GetAddressByCustomerId(_custId);
            }
        }

        public async Task addToListPoE(string ID)
        {
            PieceOfEquipment _poe = new PieceOfEquipment();
            _poe.PieceOfEquipmentID = ID;

            Tenant tenant = new Tenant();

            PieceOfEquipmentGRPC poegrpc = new PieceOfEquipmentGRPC(Client, DbFactory, await CallOptions(Component.Name));

            var listPoe = await poegrpc.GetPieceOfEquipmentXId(_poe, new CallContext());

            _poe = new PieceOfEquipment()
            {
                PieceOfEquipmentID = ID,
                SerialNumber = listPoe.SerialNumber,
                DueDate = listPoe.DueDate

            };


            _pieceOfEquipmentsFiltered.Add(_poe);

        }

        public async Task ShowModalPoEIndicator()
        {

            if (_listPoEIndicator != null && !string.IsNullOrEmpty(_listPoEIndicator.PieceOfEquipmentID))
            {
                bool confirmed = await JSRuntime.InvokeAsync<bool>("confirm", "The current indicator will be replaced");
                if (!confirmed)
                {
                    return;
                }
            }
            Dictionary<string, object> EmptyValidationDictionary = new Dictionary<string, object>();

            var parameters = new ModalParameters();
            parameters.Add("SelectOnly", true);
            parameters.Add("IsModal", true);
            parameters.Add("Checkbox", false);
            parameters.Add("Indicator", true);
            parameters.Add("CustomerId", _CustomerId);

            ModalOptions op = new ModalOptions();
            op.ContentScrollable = true;
            op.Class = "blazored-modal " + ModalSize.MediumWindow;
 
            var messageForm = Modal.Show<POEIndicator_Search>("Select Piece Of Equipment", parameters, op);
            var result = await messageForm.Result;
            Console.Write("result " + result);
            if (result != null && !result.Cancelled)
            {

     
                var res = (PieceOfEquipment)result.Data;

                PieceOfEquipment _poe = new PieceOfEquipment();
                _poe.PieceOfEquipmentID = res.PieceOfEquipmentID;


                Tenant tenant = new Tenant();

                PieceOfEquipmentGRPC poegrpc = new PieceOfEquipmentGRPC(Client, DbFactory);

                var listPoe = await poegrpc.GetPieceOfEquipmentXId(_poe, new CallContext());
                _listPoEIndicator = listPoe; 

                eq.Indicator = _listPoEIndicator;

                StateHasChanged();
            }



            if (!result.Cancelled)
                _message = result.Data?.ToString() ?? string.Empty;

        }

        public async Task DeleteIndicator()
        {
            bool confirmed = await JSRuntime.InvokeAsync<bool>("confirm", "The current indicator will be deleted");
            if (!confirmed)
            {
                return;
            }

            _listPoEIndicator = null;
            eq.Indicator = _listPoEIndicator;
            eq.IndicatorPieceOfEquipmentID = null;
        }


#pragma warning disable CS1998
        public async Task AfterAction(RangeTolerance range, string tipo)
#pragma warning restore CS1998
        {

            if (eq.IsToleranceImport == true && ResolutionComponent != null && !Loading)
            {

                List<RangeTolerance> rl = new List<RangeTolerance>();
                var rangecom = ResolutionComponent?.RangeComponent;
                if (rangecom?.RT?.Items?.Count > 0)
                {
                    var re2 = rangecom.RT.Items;
                    rl.AddRange(re2);
                }

                var resolcom = ResolutionComponent?.RangeAccuracy;
                if (resolcom?.RT?.Items?.Count > 0)
                {
                    var re3 = resolcom.RT.Items;
                    rl.AddRange(re3);
                }
              
                eq.Ranges = rl;
               
            }

        }

#pragma warning disable CS1998 
        public async Task<bool> Delete(RangeTolerance range)
#pragma warning restore CS1998 
        {

            if (eq.IsToleranceImport == true && ResolutionComponent != null)
            {

                List<RangeTolerance> rl = new List<RangeTolerance>();
                var rangecom = ResolutionComponent?.RangeComponent;
                if (rangecom?.RT?.Items?.Count > 0)
                {
                    var re2 = rangecom.RT.Items;
                    rl.AddRange(re2);

                }

                var resolcom = ResolutionComponent?.RangeAccuracy;
                if (resolcom?.RT?.Items?.Count > 0)
                {
                    var re3 = resolcom.RT.Items;
                    rl.AddRange(re3);
                }
               
                eq.Ranges = rl;
             
            }

            return true;

        }

        public async Task ChangeTestCode(ChangeEventArgs args)
        {
            await Typehead.Clear();


        }

        public Task<IEnumerable<TestCode>> SearchTestCode(string searchText)
    {
            var result = TestCodeList.Where(x => x.Code.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
            || (x.Description != null && x.Description.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
            || x.CalibrationType != null && x.CalibrationType.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
            || x.Procedure != null && x.Procedure.Name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
            );


            return Task.FromResult<IEnumerable<TestCode>>(result);

        }

        public async Task<TestCode> SearchTestCodeSelected(int? code)
        {
            var result = TestCodeList.Where(x => x.TestCodeID==code);


            return result.FirstOrDefault();

        }
        public List<Uncertainty> Uncertainty;
        public  async Task CloseUncertainty(ChangeEventArgs arg)
        {
            var a = (ModalResult)arg.Value;

            if (a.Data != null)
            {
                Uncertainty = (List<Uncertainty>)a.Data;

                if (Uncertainty.Count == 0)
                {
                    Uncertainty.Add(new Uncertainty() { IsEmpty = true });
                }

                StateHasChanged();
            }

            if (a.Cancelled)
            {
                Uncertainty = null;
            }
        }

    }





}
