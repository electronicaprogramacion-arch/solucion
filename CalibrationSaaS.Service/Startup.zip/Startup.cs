﻿using CalibrationSaaS.Application.UseCases;
using CalibrationSaaS.Data.EntityFramework;
using CalibrationSaaS.Domain.Repositories;
using CalibrationSaaS.Infraestructure.EntityFramework.DataAccess;
using CalibrationSaaS.Infraestructure.Grpc.Helpers;
using CalibrationSaaS.Infraestructure.Grpc.Services;
using CalibrationSaaS.Infraestructure.GrpcServices.Services;
using Microsoft.AspNetCore.Authentication;
//using CalibrationSaaS.Infraestructure.GrpcServices.ServicesDummies;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using OpenIddict.Validation.AspNetCore;
using ProtoBuf.Grpc.Server;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace CalibrationSaaS.Service
{
    public class Startup
    {
        //https://stackoverflow.com/questions/46010003/asp-net-core-2-0-value-cannot-be-null-parameter-name-connectionstring
        //public Microsoft.Extensions.Configuration.IConfigurationRoot Configuration { get; }
        public Microsoft.Extensions.Configuration.IConfiguration Configuration;

        public static bool test;

        public Startup(Microsoft.Extensions.Configuration.IConfiguration configuration)
        {
            Configuration = configuration;
            
        }
        

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        //Protobuf-net.
        //https://stackoverflow.com/questions/60869533/protobuf-net-grpc-client-and-net-cores-grpc-client-factory-integration
        //https://github.com/protobuf-net/protobuf-net.Grpc/blob/master/examples/pb-net-grpc/Server_CS/Startup.cs
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddHttpClient();
            var a = Configuration.GetSection("Security").GetValue<string>("Url");

            if (Configuration.GetSection("Mode").Exists())
            {
                test = Configuration.GetSection("Mode").GetValue<bool>("Test");
            }
            else
            {
                test = false;
            }


            services.AddAuthentication(options =>
            {
                options.DefaultScheme = OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme;
            });

            services.AddOpenIddict()
                .AddValidation(options =>
                {
                    // Note: the validation handler uses OpenID Connect discovery
                    // to retrieve the address of the introspection endpoint.
                    options.SetIssuer("https://localhost:44395/");
                    options.AddAudiences("rs_dataEventRecordsApi");

                    // Configure the validation handler to use introspection and register the client
                    // credentials used when communicating with the remote introspection endpoint.
                    options.UseIntrospection()
                            .SetClientId("rs_dataEventRecordsApi")
                            .SetClientSecret("dataEventRecordsSecret");

                    // disable access token encyption for this
                    options.UseAspNetCore();

                    // Register the System.Net.Http integration.
                    options.UseSystemNetHttp();

                    // Register the ASP.NET Core host.
                    options.UseAspNetCore();
                });

            services.AddAuthorization(options =>
            {
                options.AddPolicy("dataEventRecordsPolicy", policyUser =>
                {
                    policyUser.RequireClaim("scope", "dataEventRecords");
                });
            });

            services.AddGrpc();


            //services.AddCors(o => o.AddPolicy("AllowAll", builder =>
            //{
            //    builder.AllowAnyOrigin()
            //           .AllowAnyMethod()
            //           .AllowAnyHeader()
            //           .WithExposedHeaders("Grpc-Status", "Grpc-Message", "Grpc-Encoding", "Grpc-Accept-Encoding");
            //}));
          

            

            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //   .AddJwtBearer(options =>
            //   {
            //       options.RequireHttpsMetadata = false;
            //       options.Authority = Configuration.GetSection("Security").GetValue<string>("Url");//"https://localhost:5005";
            //       options.Audience = "GRPC";
            //       options.TokenValidationParameters = new TokenValidationParameters()
            //       {
            //           NameClaimType =  "name",
            //           RoleClaimType = "role"
            //       };
            //   });


            //services.AddAuthorization();



            services.AddHttpClient();
            
            services.AddGrpc(options =>
            {
                options.Interceptors.Add<LoggerInterceptor>();
                options.EnableDetailedErrors = true;               
                options.MaxReceiveMessageSize = 10 * 1024 * 1024; // 2 MB
                options.MaxSendMessageSize = 10 * 1024 * 1024; // 5 MB
               


            });

            services.AddGrpcReflection();

          

            //https://www.youtube.com/watch?v=ZM0XeSjuwbc&t=4530s
            services.AddCodeFirstGrpc(config =>
            {
                config.ResponseCompressionLevel = System.IO.Compression.CompressionLevel.Optimal;
               
            });

            const string corsPolicy = "_corsPolicy";
            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  policy =>
                                  {
                                      policy.WithOrigins("https://localhost:5001",
                                                         "http://localhost:5000")
                                            .AllowAnyHeader()
                                            .AllowAnyMethod();
                                  });
            });



            if (test)
            {
                services.AddDbContext<ApplicationDbContext>(options =>
               //options.UseInMemoryDatabase("identity")    
               //options.UseSqlite(Configuration.GetConnectionString("DefaultConnection"))
               options.UseInMemoryDatabase(databaseName: "Test"));

                services.AddDbContext<CalibrationSaaSDBContext>(options => options.UseInMemoryDatabase(databaseName: "Test"), ServiceLifetime.Transient);
            }
            else
            {
                //services.AddDbContext<CalibrationSaaSDBContext>(options =>
                //options.UseSqlServer(Microsoft.Extensions.Configuration
                //.ConfigurationExtensions.GetConnectionString(this.Configuration, "DefaultConnection"))
                //.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                //, ServiceLifetime.Transient);

                services.AddDbContext<ApplicationDbContext>(options =>
              
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

                services.AddDbContextFactory<CalibrationSaaSDBContext>(options =>
                options.UseSqlServer(Microsoft.Extensions.Configuration
                .ConfigurationExtensions.GetConnectionString(this.Configuration, "DefaultConnection")
                , providerOptions => providerOptions.EnableRetryOnFailure().MigrationsAssembly("CalibrationSaaS.Infraestructure.GrpcServices"))
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                .EnableDetailedErrors(true)
                .EnableSensitiveDataLogging(true)
                , ServiceLifetime.Transient);



               

                //services.AddDbContextFactory<TestDbContext>(options =>
                //options.UseSqlServer(Microsoft.Extensions.Configuration
                //.ConfigurationExtensions.GetConnectionString(this.Configuration, "DefaultConnection")
                //, providerOptions => providerOptions.EnableRetryOnFailure().MigrationsAssembly("CalibrationSaaS.Infraestructure.GrpcServices"))
                //.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                //.EnableDetailedErrors(true)
                //.EnableSensitiveDataLogging(true)
                //, ServiceLifetime.Transient);
                
                //services.AddScoped<UserGenerator>();
                

                //services.AddEntityFrameworkNpgsql().AddDbContext<Test3.TestDbContext>();




            }


            services.AddLogging(config =>
            {
                config.AddDebug();
                config.AddConsole();
                //etc
            });

            services.AddControllers()
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                options.JsonSerializerOptions.MaxDepth = 32; 
            });

            //Dependecy injection
            //https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-3.1
            //https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-3.1#service-lifetimes
            //
            services.AddTransient<ICustomerRepository, CustomerRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<CustomerUseCases, CustomerUseCases>();
            services.AddTransient<SampleUseCases, SampleUseCases>();
            
            //services.AddTransient<CustomerAddressUseCases, CustomerAddressUseCases>();
            //services.AddTransient<ICustomerAddressRepository, CustomerAddressRepositoryEF>();
            services.AddTransient<IPieceOfEquipmentRepository, PieceOfEquipmentRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<PieceOfEquipmentUseCases, PieceOfEquipmentUseCases>();
            services.AddTransient<BasicsUseCases, BasicsUseCases>();
            services.AddTransient<IBasicsRepository, BasicsRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<AssetsUseCases, AssetsUseCases>();
            services.AddTransient<IAssetsRepository, AssetsRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<IUOMRepository, UOMRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<UOMUseCases, UOMUseCases>();
            services.AddTransient<WorkOrderDetailUseCase, WorkOrderDetailUseCase>();
            services.AddTransient<IWorkOrderDetailRepository, WODRepositoryEF<CalibrationSaaSDBContext>>();
            services.AddTransient<IIdentityRepository, IdentityClient.IdentityClient>();


            services.AddSingleton<ValidatorHelper, ValidatorHelper>();
            //services.AddBlazoredModal();
           
           
            


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            
            //app.UseRouting();
            //        app.UseRouting(routes => {
            //            routes.MapGrpcService<ContentStoreImpl>()
            //              .RequireAuthorization();
            //        }
            //);

            //https://blog.sanderaernouts.com/grpc-aspnetcore-azure-ad-authentication
            //app.UseAuthentication(); // UseAuthentication must come before UseAuthorization
            //app.UseAuthorization();

            app.UseHttpsRedirection();
            app.UseRouting();
            //app.UseCors("AllowAll");
            app.Use((context, next) =>
            {
                context.Response.Headers.AccessControlAllowOrigin = "*";
                context.Response.Headers.AccessControlExposeHeaders = "*";
                return next.Invoke();
            });
            //app.UseCors(x => x.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
            app.UseCors("_corsPolicy");
            app.UseAuthentication();
            app.UseAuthorization();
           
            app.UseGrpcWeb(new GrpcWebOptions { DefaultEnabled = true });

           


            //TODO: change to config file to handle things
            app.UseEndpoints(endpoints =>
            {
               

                endpoints.MapGrpcService<UOMServices>().EnableGrpcWeb().RequireCors("AllowAll");
                //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<ReportService>().EnableGrpcWeb().RequireCors("AllowAll");
                //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<WorkOrderDetailServices>().EnableGrpcWeb().RequireCors("AllowAll");
                     //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                         //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));


                endpoints.MapGrpcService<CustomerService>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                //endpoints.MapGrpcService<CustomerService>().RequireAuthorization().EnableGrpcWeb().RequireCors("AllowAll");
                //       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                //           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas.azurewebsites.net"));

                endpoints.MapGrpcService<SampleService>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas.azurewebsites.net"));


                endpoints.MapGrpcService<BasicsServices>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));


                endpoints.MapGrpcService<AddressServices>().EnableGrpcWeb().RequireCors("AllowAll");
                      //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                          //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));


               
                endpoints.MapGrpcService<CustomerAddressService>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<PieceOfEquipmentService>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<WorkOrderService>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<AssetsServices>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));

                endpoints.MapGrpcService<FileUpload>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));


                 endpoints.MapGrpcService<ComponentServices>().EnableGrpcWeb().RequireCors("AllowAll");
                       //.RequireCors(cors => cors.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
                           //.WithOrigins("http://localhost:54070", "https://localhost:44351", "https://localhost:44355", "https://calibrationsaas-staging.azurewebsites.net", "https://calibrationsaas-proproduction.azurewebsites.net", "https://calibrationsaas.azurewebsites.net", "https://localhost:44352"));


                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Communication with gRPC endpoints must be made through a gRPC client. To learn how to create a client, visit: https://go.microsoft.com/fwlink/?linkid=2086909");
                });

                if (env.IsDevelopment())
                {
                    endpoints.MapGrpcReflectionService();
                }

            });
            

            var httpsSection = Configuration.GetSection("HttpServer:Endpoints:Https");
            if (httpsSection.Exists())
            {
            var httpsEndpoint = new EndpointConfiguration();
            httpsSection.Bind(httpsEndpoint);
            app.UseRewriter(new RewriteOptions().AddRedirectToHttps(
            statusCode: env.IsDevelopment() ? StatusCodes.Status302Found : StatusCodes.Status301MovedPermanently,
            sslPort: httpsEndpoint.Port));
            }
         
          

            app.UseStaticFiles();



        }
    }

    public class MyClass
    {

        private readonly ILogger<MyClass> _logger;


        public MyClass(ILogger<MyClass> logger)
        {
            _logger = logger;
        }
        public void MyFunc()
        {
            _logger.Log(LogLevel.Error, "My Message");
        }
    }

}
